export class List<T> {
    count = 0;
    result: T[] = [];
    _links: any;
}
