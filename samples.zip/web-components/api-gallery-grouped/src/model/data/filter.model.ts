export class FilterModel {
    categories: string[] = [];
    maturityStatus: string[] = [];
    tags: string[] = [];
    businessTerms: string[] = [];
    type: string[] = [];
}