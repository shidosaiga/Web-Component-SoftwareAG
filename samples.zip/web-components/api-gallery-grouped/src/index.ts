import {GalleryPageComponent} from "./components/gallery-page-component";
import {ApiElement} from "./components/api.element";

customElements.define("api-gallery-grouped", GalleryPageComponent)
customElements.define("api-gallery-api", ApiElement)