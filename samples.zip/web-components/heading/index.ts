import {HeadingComponent} from './src/heading-component';

customElements.define('custom-heading', HeadingComponent);
