import {ApiGalleryItemElement} from './components/api-gallery-item/api-gallery-item-element';

customElements.define('api-gallery-box', ApiGalleryItemElement);
