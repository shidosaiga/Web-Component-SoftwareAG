# About Web Component Samples


### Development 
This project is a single youtube video rendering JavaScript file.

### Pre requirement


### Tag included

`wc-youtube` 

Renders the provided video with specified width/height 

