import {BannerComponent} from './src/banner-component';

customElements.define('custom-banner', BannerComponent);
