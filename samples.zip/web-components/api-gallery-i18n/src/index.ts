import {ApiGalleryI18ninfo} from './components/api-gallery-i18n/api-gallery-i18ninfo';


customElements.define('api-gallery-i18ninfo', ApiGalleryI18ninfo);
