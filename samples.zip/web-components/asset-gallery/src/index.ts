import {AssetBox} from "./components/asset-box";


customElements.define("wc-asset-box", AssetBox)
